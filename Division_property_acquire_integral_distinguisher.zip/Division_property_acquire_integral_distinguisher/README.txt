This code can be used to acquire the integral distinguisher by using the method proposed in section 5.



An instance is given in this code. The cube is [0,1,2,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,21,22,23,26,27,28,29,30,31,32,33,36,37,40,41,42,43,45,47,48,49,51,54,57,58,59,60,61,62,63,64,66,68,73,74,75,77,78,82,83,84,85,86,87,89,91,92,93,94,96,97,98,100,101,103,105,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,126,127],then, we can determine that non-cube bits uninvolve in the superpoly is 
[6, 20, 25, 34, 35, 38, 39, 44, 50, 52, 53, 55, 56, 65, 67, 69, 70, 71, 72, 79, 80, 81, 88, 90, 95, 99, 102, 104, 106, 123, 124, 125] 
