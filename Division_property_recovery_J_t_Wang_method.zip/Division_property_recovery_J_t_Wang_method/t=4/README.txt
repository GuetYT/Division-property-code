This code can  acquire all 4-degree monomials may involve in the superpoly by using the method in "  Improved Division Property Based Cube Attacks Exploiting Algebraic Properties of Superpoly".

We only give an example.  The cube is [3, 4, 7, 15, 20, 24, 30, 31, 40, 43, 50, 60, 70, 79, 86, 89, 95, 96, 97, 102, 103, 106, 111, 116]��the upperbounding degree of superpoly is 14. 

The result is written in the file of "result2.txt"