from gurobipy import *
import os

class Morus:
    
    def __init__(self , Step, cube , output_bit , t):
        self.Step       = Step 
        self.cube       = cube                                                   #  The cube index  [0 , 127)
        self.output_bit = output_bit
        self.t = t
        self.filename_model_2  = "Morus_"  + str(self.Step)   +  "_"  +   str(self.output_bit) + "_" + str(2) +  ".lp"                      # The MILP model
        self.filename_result   = "Morus_"  + str(self.Step)   +  "_"  +   str(self.output_bit)   +  ".txt"                                  # The result
        
    #     0 <= step <=15   0 =< round <= 5   0=<block<= 5          0<=bit_index<=128      
    
    def Create_variable(self , variable , step , round , block , index):                                                               # Create variables
        array = []
        for i in index:
            array.append((variable + '_' + str(step) + '_' + str(round) + '_' + str(block) + '_' + str(i)))
        return array[:]
    
    
    # Left rotation operation b-bit for every 32-bit word 
    def Rot_Function_32(self , Morus_state_32 , b):                              
        eqn = [" " for i in  range(0 , 32)]
        for i in range(0 , 32):
            eqn[(i - b + 32) % 32]  =  Morus_state_32[i]
        return eqn[:]
        
    # Left rotation operation w-bit for every 128-bit word
    def Rot_Function_128(self , Morus_state_128 , w):                                                                            #
        eqn = [" " for i in  range(0 , 128)]
        for i in range(0 , 128):
            eqn[(i- w + 128) % 128]  =  Morus_state_128[i]
        for i in range(0 , 128):
            Morus_state_128[i] = eqn[i]            
 
 
    # MILP model of COPY used in AND operation of MORUS-640-128
    def copy_AND_Function_128(self,  Morus_128, step, round , block):                                     
        fileobj_2 = open(self.filename_model_2, "a")
        Morus_copy_AND   = self.Create_variable("Morus_copyAND"       , step , round , block , range(0 , 128))
        Morus_copy_saved = self.Create_variable("Morus_copyAND_saved" , step , round , block , range(0 , 128))
        
        for i in range(0 , 128):
            eqn = []
            eqn.append(Morus_128[i])
            eqn.append(Morus_copy_AND[i])
            eqn.append(Morus_copy_saved[i])
            temp  = " - ".join(eqn)
            temp  = temp + " =  0 "   
            fileobj_2.write(temp)
            fileobj_2.write('\n')
            
        fileobj_2.close()
        for i in range(0 , 128):
            Morus_128[i] = Morus_copy_saved[i]
        return  Morus_copy_AND[:]



    # MILP model of COPY used in  XOR operation of MORUS-640-128           
    def copy_XOR_Function_128(self, Morus_128 , step , round , block):
        fileobj_2 = open(self.filename_model_2, "a") 
        Morus_copy_XOR   = self.Create_variable("Morus_copyXOR"       , step , round , block , range(0 , 128))
        Morus_copy_saved = self.Create_variable("Morus_copyXOR_saved" , step , round , block , range(0 , 128))
        for i in range(0 , 128):
            eqn = []
            eqn.append(Morus_128[i])
            eqn.append(Morus_copy_XOR[i])
            eqn.append(Morus_copy_saved[i])
            temp  = " - ".join(eqn)
            temp = temp + " =  0 "   
            fileobj_2.write(temp)
            fileobj_2.write('\n')
        fileobj_2.close()

        for i in range(0 , 128):
            Morus_128[i] = Morus_copy_saved[i] 
        return  Morus_copy_XOR[:]
        
        
        
    # The AND operation of flag in Morus-640-128, and  MORUS_block1, MORUS_block2 is an vector of 128-bit  
    def And_Morus_flag(self , MORUS_block1 , MORUS_block2):                                             
        MORUS_AND_output = range(0 , 128)
        for i in range(0 , 128):
            if(MORUS_block1[i] == 0)   and (MORUS_block2[i] == 0):
                MORUS_AND_output[i] = 0
            elif(MORUS_block1[i] == 1) and (MORUS_block2[i] == 1):
                MORUS_AND_output[i] = 1
            elif(MORUS_block1[i] == 'a') and (MORUS_block2[i] == 'a'):
                MORUS_AND_output[i] = 'a'   
            elif(MORUS_block1[i] == 0) and (MORUS_block2[i] == 1):
                MORUS_AND_output[i] = 0 
            elif(MORUS_block1[i] == 0) and (MORUS_block2[i] == 'a'):
                MORUS_AND_output[i] =  0
            elif(MORUS_block1[i] == 1) and (MORUS_block2[i] == 'a'):
                MORUS_AND_output[i] =  'a'
            elif(MORUS_block1[i] == 1) and (MORUS_block2[i] == 0):
                MORUS_AND_output[i] =  0    
            elif(MORUS_block1[i] == 'a') and (MORUS_block2[i] == 0):
                MORUS_AND_output[i] =  0    
            elif (MORUS_block1[i] == 'a') and (MORUS_block2[i] == 1):
                MORUS_AND_output[i] =  'a'             
        return MORUS_AND_output[:]   
    
    
    
    # The XOR operation of flag in Morus-640-128, and  MORUS_block1, MORUS_block2 and MORUS_block3 are vectors of 128-bit    
    def XOR_Morus_flag(self, MORUS_block1, MORUS_block2, MORUS_block3):
        Morus_XOR_output = range(0 , 128)
        for i in  range(0 , 128):
            state_XOR = [MORUS_block1[i] , MORUS_block2[i], MORUS_block3[i]]
            Morus_XOR_output[i] = self.XOR_Morus_2_temp(state_XOR , range(0 , 3))
        return Morus_XOR_output[:]
            
# The XOR operation of flag in Morus-640-128, and only the flag of b[i], i is in b_index, is included in XOR operation.           
    def XOR_Morus_2_temp(self , b , b_index):                                        
        i = 1
        b_temp = b[b_index[0]]
        if len(b_index) == 1:
            sum = b[b_index[0]]
        if len(b_index) > 1:
            for j in range(0 , len(b_index) - 1):
                if (b_temp == 1) and (b[b_index[i]] == 1):
                    b_temp = 0
                        
                elif (b_temp == 0) and (b[b_index[i]] == 0):
                    b_temp = 0
                            
                elif (b_temp == 'a') and (b[b_index[i]] == 'a'):
                    b_temp = 'a'   
                            
                elif (b_temp == 1) and (b[b_index[i]] == 0):
                    b_temp = 1 
                        
                elif (b_temp == 1) and (b[b_index[i]] == 'a'):
                    b_temp = 'a'
                        
                elif (b_temp == 0) and (b[b_index[i]] == 'a'):
                    b_temp =  'a'
                        
                elif (b_temp == 0) and (b[b_index[i]] == 1):
                    b_temp =  1   
                            
                elif (b_temp == 'a') and (b[b_index[i]] == 1):
                    b_temp = 'a'   
                            
                elif (b_temp == 'a') and (b[b_index[i]] == 0):
                    b_temp =  'a' 
                i = i + 1
        return b_temp             
        
        
    #This is the function of Rotl_128_32 in MORUS-640-128,  Morus_cipher_state0,......, Morus_cipher_state4 are vectors about flag bits, b1 is rotation constants
    def Morus_Rot_Cipher(self, Morus_cipher_state0 , Morus_cipher_state1 , Morus_cipher_state2 , Morus_cipher_state3 , Morus_cipher_state4,  b1):  
        Morus_And_state = range(0 , 128)
        
        Morus_temp  = range(0 , 32)
        
        Morus_temp0 = range(0 , 32)
        Morus_temp1 = range(0 , 32)
        Morus_temp2 = range(0 , 32)
        Morus_temp3 = range(0 , 32)
        
        Morus_And_state             =   self.And_Morus_flag(Morus_cipher_state1, Morus_cipher_state2)
        Morus_cipher_state0_temp    =   self.XOR_Morus_flag(Morus_cipher_state0 , Morus_And_state , Morus_cipher_state3)
        
        for i in range(0 , 32):
            Morus_temp[i] = Morus_cipher_state0_temp[i]
        Morus_temp0 = self.Rot_Function_32(Morus_temp , b1)
        
        for i in range(0 , 32):
            Morus_temp[i] = Morus_cipher_state0_temp[i + 32]
        Morus_temp1 = self.Rot_Function_32(Morus_temp , b1)
        
        for i in range(0 , 32):
            Morus_temp[i] = Morus_cipher_state0_temp[i + 64]
        Morus_temp2 = self.Rot_Function_32(Morus_temp , b1)  
        
        for i in range(0 , 32):
            Morus_temp[i] = Morus_cipher_state0_temp[i + 96]
        Morus_temp3 = self.Rot_Function_32(Morus_temp , b1)
        
        
        for i in range(0 , 32):
            Morus_cipher_state0[i]      = Morus_temp0[i]
            
        for i in range(0 , 32):
            Morus_cipher_state0[i + 32] = Morus_temp1[i]
            
        for i in range(0 , 32):
            Morus_cipher_state0[i + 64] = Morus_temp2[i]
            
        for i in range(0 , 32):
            Morus_cipher_state0[i + 96] = Morus_temp3[i]   
    
 
        
        
       
    # This function can be used to construct the  MILP model of Rotl_128_32 with flag technical, Morus_copy_AND_1,..... ,Morus_next_round are variables of MILP model, Morus_state0,.....,Morus_state3 are flag bit of the corresponding MILP variables.
    def Morus_Rot_128_32(self , Morus_copy_AND_1 , Morus_copy_AND_2 , Morus_current_round , Morus_copy_XOR_1 , Morus_next_round , Morus_state1, Morus_state2, step , round , block , b):   
        fileobj_2         = open(self.filename_model_2, "a")

        Morus_AND_output  = self.Create_variable("AND" , step , round , block , range(0 , 128))            

        Morus_temp        = range(0  ,32) 
        Morus_state_temp1 = range(0  ,32)
        Morus_state_temp2 = range(0  ,32)
        Morus_state_temp3 = range(0  ,32)
        Morus_state_temp4 = range(0  ,32)

        #The AND Model

        for i in range(0 , 128):                                                        #The model of AND, add the flag technical 
            if(((Morus_state1[i] == 0) or (Morus_state2[i] == 0))):
                fileobj_2.write(Morus_AND_output[i] + ' = 0')
                fileobj_2.write('\n')

        for i in range(0 , 128):
            fileobj_2.write(Morus_AND_output[i] + " - " + Morus_copy_AND_1[i] + ' >= 0')

            fileobj_2.write('\n')

            fileobj_2.write(Morus_AND_output[i] + " - " + Morus_copy_AND_2[i] + ' >= 0')

            fileobj_2.write('\n')


        #The XOR Model

        for i in range(0 , 128):
            eqn = []
            eqn.append(Morus_next_round[i])
            eqn.append(Morus_current_round[i])
            eqn.append(Morus_AND_output[i])
            eqn.append(Morus_copy_XOR_1[i])
            temp  = " - ".join(eqn)
            temp = temp + " =  0 "
            fileobj_2.write(temp)
            fileobj_2.write('\n')
        fileobj_2.close()

        for i in range(0 , 32):
            Morus_temp[i] = Morus_next_round[i]
        Morus_state_temp1 = self.Rot_Function_32(Morus_temp , b)                                        # The first 32 bits rotation

        for i in range(0 , 32):
            Morus_temp[i] = Morus_next_round[32 + i]
        Morus_state_temp2 = self.Rot_Function_32(Morus_temp , b)

        for i in range(0 , 32):
            Morus_temp[i] = Morus_next_round[64 + i]
        Morus_state_temp3 = self.Rot_Function_32(Morus_temp , b)        

        for i in range(0 , 32):
            Morus_temp[i] = Morus_next_round[96 + i]
        Morus_state_temp4 = self.Rot_Function_32(Morus_temp , b)  



        for i in range(0  , 32):
            Morus_current_round[i]      =  Morus_state_temp1[i]                                       # the state of one rigister is changed

        for i in range(0  , 32):
            Morus_current_round[i + 32] =  Morus_state_temp2[i]

        for i in range(0  , 32):
            Morus_current_round[i + 64] =  Morus_state_temp3[i]

        for i in range(0  , 32):
            Morus_current_round[i + 96] =  Morus_state_temp4[i]   
            
            
            
    # The  MILP model of one step function in MORUS, Morus_state0_128,.....,Morus_state4_128 are MILP variables,  Morus_cipher_state0,...., Morus_cipher_state4 are the flag bit of the corresponding MILP variables.
    def  Morus_one_step_Function_640_128_flag(self, Morus_state0_128 , Morus_state1_128, Morus_state2_128 , Morus_state3_128 , Morus_state4_128 , Morus_cipher_state0 , Morus_cipher_state1 , Morus_cipher_state2 , Morus_cipher_state3 , Morus_cipher_state4 , step):
    
        #The 0th round in Step
        copy_AND_Function_128_0_1 = self.copy_AND_Function_128(Morus_state1_128  , step , 0 , 1)               # The 0th round , 1th block
        copy_AND_Function_128_0_2 = self.copy_AND_Function_128(Morus_state2_128  , step , 0 , 2)               # The 0th round , 2th block
        copy_XOR_Function_128_0_3 = self.copy_XOR_Function_128(Morus_state3_128  , step , 0 , 3)
        
        
        
        Morus_next_round_128_1_0 = self.Create_variable('Morus_state' , step , 1 , 0 , range(0 , 128))        # The state of 1th round 0 block
        
        self.Morus_Rot_Cipher(Morus_cipher_state0 , Morus_cipher_state1 , Morus_cipher_state2 , Morus_cipher_state3 , Morus_cipher_state4 , 5)
        
        self.Morus_Rot_128_32(copy_AND_Function_128_0_1,  copy_AND_Function_128_0_2 , Morus_state0_128 ,  copy_XOR_Function_128_0_3 , Morus_next_round_128_1_0 , Morus_cipher_state1, Morus_cipher_state2, step , 0 , 0 , 5)
        self.Rot_Function_128(Morus_cipher_state3 , 32)
        self.Rot_Function_128(Morus_state3_128, 32)
        
        
        
        #The 1th round in step
        copy_AND_Function_128_1_2 = self.copy_AND_Function_128(Morus_state2_128  , step , 1 , 2)               # The  1th round , 2th block
        copy_AND_Function_128_1_3 = self.copy_AND_Function_128(Morus_state3_128  , step , 1 , 3)               # The  1th round , 3th block
        copy_XOR_Function_128_1_4 = self.copy_XOR_Function_128(Morus_state4_128  , step , 1 , 4)
        
        Morus_next_round_128 = self.Create_variable('Morus_state' , step , 2 , 1 , range(0 , 128))             #  The state of 2th round 1 block ,  the same as output of  XOR
        
        self.Morus_Rot_Cipher( Morus_cipher_state1 , Morus_cipher_state2 , Morus_cipher_state3 , Morus_cipher_state4 , Morus_cipher_state0 , 31)
        
        self.Morus_Rot_128_32(copy_AND_Function_128_1_2 ,  copy_AND_Function_128_1_3 , Morus_state1_128 ,  copy_XOR_Function_128_1_4 , Morus_next_round_128 , Morus_cipher_state2, Morus_cipher_state3 ,step , 1 , 1 , 31) 
        self.Rot_Function_128(Morus_cipher_state4, 64)
        self.Rot_Function_128(Morus_state4_128, 64)
        
        
        #The 2th round in step
        copy_AND_Function_128_2_3 = self.copy_AND_Function_128(Morus_state3_128  , step , 2 , 3)               # The  2th round , 2th block
        copy_AND_Function_128_2_4 = self.copy_AND_Function_128(Morus_state4_128  , step , 2 , 4)               # The  2th round , 3th block
        copy_XOR_Function_128_2_0 = self.copy_XOR_Function_128(Morus_state0_128  , step , 2 , 0)
        
        Morus_next_round_128 = self.Create_variable('Morus_state' , step , 3 , 2 , range(0 , 128))               #  The state of 2th round 1 block
        
        self.Morus_Rot_Cipher( Morus_cipher_state2 , Morus_cipher_state3 , Morus_cipher_state4 , Morus_cipher_state0 , Morus_cipher_state1 , 7)
        
        self.Morus_Rot_128_32(copy_AND_Function_128_2_3 ,  copy_AND_Function_128_2_4 , Morus_state2_128 ,  copy_XOR_Function_128_2_0 , Morus_next_round_128 , Morus_cipher_state3, Morus_cipher_state4, step , 2 , 2 , 7) 
        self.Rot_Function_128(Morus_cipher_state0, 96) 
        self.Rot_Function_128(Morus_state0_128, 96)     
        
        
        #The 3th round in step
        copy_AND_Function_128_3_0 = self.copy_AND_Function_128(Morus_state0_128  , step , 3 , 0)                 # The  3th round , 0th block
        copy_AND_Function_128_3_4 = self.copy_AND_Function_128(Morus_state4_128  , step , 3 , 4)                 # The  3th round , 4th block
        copy_XOR_Function_128_3_1 = self.copy_XOR_Function_128(Morus_state1_128  , step , 3 , 1)
        
        Morus_next_round_128 = self.Create_variable('Morus_state' , step , 4 , 3 , range(0 , 128))               #  The state of 4th round 3 block
        
        self.Morus_Rot_Cipher( Morus_cipher_state3 , Morus_cipher_state4 , Morus_cipher_state0 , Morus_cipher_state1 , Morus_cipher_state2  , 22)
        self.Morus_Rot_128_32( copy_AND_Function_128_3_0 ,   copy_AND_Function_128_3_4 , Morus_state3_128 ,   copy_XOR_Function_128_3_1 , Morus_next_round_128 , Morus_cipher_state0, Morus_cipher_state4, step , 3 , 3 , 22) 
        self.Rot_Function_128(Morus_cipher_state1 , 64) 
        self.Rot_Function_128(Morus_state1_128    , 64) 
        
        #The 4th round in step
        copy_AND_Function_128_4_0 = self.copy_AND_Function_128(Morus_state0_128  , step , 4 , 0)               # The  3th round , 0th block
        copy_AND_Function_128_4_1 = self.copy_AND_Function_128(Morus_state1_128  , step , 4 , 1)               # The  3th round , 4th block
        copy_XOR_Function_128_4_2 = self.copy_XOR_Function_128(Morus_state2_128  , step , 4 , 2)
        
        Morus_next_round_128 = self.Create_variable('Morus_state' , step + 1 ,  0 , 4 , range(0 , 128))               #  The state of 4th round 3 block
        
        self.Morus_Rot_Cipher( Morus_cipher_state4 , Morus_cipher_state0 , Morus_cipher_state1 , Morus_cipher_state2 , Morus_cipher_state3  , 13)
        self.Morus_Rot_128_32(copy_AND_Function_128_4_0 , copy_AND_Function_128_4_1 , Morus_state4_128 , copy_XOR_Function_128_4_2 , Morus_next_round_128 , Morus_cipher_state0, Morus_cipher_state1, step , 4 , 4 , 13) 
        
        self.Rot_Function_128(Morus_cipher_state2 , 32) 
        self.Rot_Function_128(Morus_state2_128 , 32)    
        
         
    
    def Morus_num_step_Function_640_128(self , step, Morus_cipher_state0 , Morus_cipher_state1 , Morus_cipher_state2, Morus_cipher_state3 , Morus_cipher_state4):                                        # The function of the certain number steps
        Morus_state0_128 = self.Create_variable('Morus_state' , 0 , 0 , 0 , range(0 , 128))
        Morus_state1_128 = self.Create_variable('Morus_state' , 0 , 0 , 1 , range(0 , 128))
        Morus_state2_128 = self.Create_variable('Morus_state' , 0 , 0 , 2 , range(0 , 128))
        Morus_state3_128 = self.Create_variable('Morus_state' , 0 , 0 , 3 , range(0 , 128))
        Morus_state4_128 = self.Create_variable('Morus_state' , 0 , 0 , 4 , range(0 , 128))
        
      
        
        fileobj_2 = open(self.filename_model_2 ,"a")
        fileobj_2.write("Subject To\n")
        fileobj_2.close()
        
        
        for i in range(0 , step):
            self.Morus_one_step_Function_640_128_flag(Morus_state0_128 , Morus_state1_128, Morus_state2_128 , Morus_state3_128 , Morus_state4_128 , Morus_cipher_state0 , Morus_cipher_state1 , Morus_cipher_state2, Morus_cipher_state3 , Morus_cipher_state4 , i )
            
                                                     #The final  restrictions
        fileobj_2 = open(self.filename_model_2 , "a") 
        
    
    
        fileobj_2.write(Morus_state0_128[self.output_bit] + ' = 1')
        fileobj_2.write('\n')
        
        
        
        
        for i in [p for p in range(0 , 128) if p not in [self.output_bit]]:                  # The state of 
            fileobj_2.write(Morus_state0_128[i] + ' = 0')
            fileobj_2.write('\n')
        
        for i in range(0 , 128):
            fileobj_2.write(Morus_state3_128[i] + ' = 0')
            fileobj_2.write('\n')
            
        for i in range(0 , 128):  
            fileobj_2.write(Morus_state2_128[i] + ' = 0')
            fileobj_2.write('\n') 
            
        for i in range(0 , 128):  
            fileobj_2.write(Morus_state1_128[i] + ' = 0')
            fileobj_2.write('\n') 
            
        for i in range(0 , 128):  
            fileobj_2.write(Morus_state4_128[i] + ' = 0')
            fileobj_2.write('\n')
        
        fileobj_2.close()
        
        
# The initialization of all state 

    def init(self):                                                                          # The initialization of all state
        Morus_state0_128 = self.Create_variable('Morus_state' , 0 , 0 , 0 , range(0 , 128))
        Morus_state1_128 = self.Create_variable('Morus_state' , 0 , 0 , 1 , range(0 , 128))
        Morus_state2_128 = self.Create_variable('Morus_state' , 0 , 0 , 2 , range(0 , 128))
        Morus_state3_128 = self.Create_variable('Morus_state' , 0 , 0 , 3 , range(0 , 128))
        Morus_state4_128 = self.Create_variable('Morus_state' , 0 , 0 , 4 , range(0 , 128))
        
        
        
       
        fileobj_2 = open(self.filename_model_2, "a")
        
        for i in range(0 , 128):
            fileobj_2.write(Morus_state2_128[i]+ ' = 0')
            fileobj_2.write('\n')
            
        for i in range(0 , 128):
            fileobj_2.write(Morus_state3_128[i]+ ' = 0')
            fileobj_2.write('\n')              
        
        for i in range(0 , 128):
            fileobj_2.write(Morus_state4_128[i]+ ' = 0')
            fileobj_2.write('\n')             
            
        eqn = []
        for i in range(0, 128):
            eqn.append(Morus_state1_128[i])
        temp = " + ".join(eqn)
        temp = temp + "  = " + str(self.t)
        fileobj_2.write(temp)
        fileobj_2.write('\n') 
            
        for i in self.cube:
            fileobj_2.write(Morus_state0_128[i]+ ' = 1')
            fileobj_2.write('\n')            
            
        for i in [p for p in range(0 , 128) if p not in self.cube]:
            fileobj_2.write(Morus_state0_128[i]+ ' = 0')
            fileobj_2.write('\n')            
            
        fileobj_2.close()        
        
 

        
        
    # Define some binary variables in the MILP model of MORUS-640-128   
    def Binary(self):
        fileobj_2 = open(self.filename_model_2, "a")

        fileobj_2.write('Binary')
        fileobj_2.write('\n')


        # The all variables of first round in AND
        for i in range(0 , self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 0 , 1 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 0 , 2 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n')


        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 0 , 1 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 0 , 2 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n') 

        # The all  variables of 1th  round   in AND  
        for i in range(0 , self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 1 , 2 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 1 , 3 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n')


        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 1 , 2 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n')


        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 1 , 3 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n')

    # The all  variables of 2th  round   in AND       
        for i in range(0 , self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 2 , 3 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 2 , 4 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n')


        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 2 , 3 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n') 


        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 2 , 4 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n') 


    # The all  variables of 3th  round   in AND       
        for i in range(0 , self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 3 , 0 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 3 , 4 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n') 


        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 3 , 0 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n')


        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 3 , 4 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n') 


    # The all  variables of 4th  round   in AND       
        for i in range(0 , self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 4 , 0 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n')

        for i in range(0 ,self.Step):
            Morus_copy_AND = self.Create_variable("Morus_copyAND"  , i , 4 , 1 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_AND[j])
                fileobj_2.write('\n') 


        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 4 , 0 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n')        

        for i in range(0 , self.Step):
            Morus_copy_saved  = self.Create_variable("Morus_copyAND_saved"  , i , 4 , 1 ,  range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_saved[j])
                fileobj_2.write('\n')

    # The all  variables of 0th  round   in XOR 
        for i in range(0 , self.Step):  
            Morus_copy_XOR   = self.Create_variable("Morus_copyXOR"       , i , 0 , 3 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_XOR[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_copy_saved = self.Create_variable("Morus_copyXOR_saved" , i , 0 , 3 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write( Morus_copy_saved[j])
                fileobj_2.write('\n') 

    # The all  variables of 1th  round   in  XOR  
        for i in range(0 ,self.Step):  
            Morus_copy_XOR   = self.Create_variable("Morus_copyXOR"       , i , 1 , 4 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_XOR[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step ):
            Morus_copy_saved = self.Create_variable("Morus_copyXOR_saved" , i , 1 , 4 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write( Morus_copy_saved[j])
                fileobj_2.write('\n')

    # The all  variables of 2th  round   in  XOR      

        for i in range(0 , self.Step):  
            Morus_copy_XOR   = self.Create_variable("Morus_copyXOR"       , i , 2 , 0 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_XOR[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_copy_saved = self.Create_variable("Morus_copyXOR_saved" , i , 2 , 0 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write( Morus_copy_saved[j])
                fileobj_2.write('\n') 

    # The all  variables of 3th  round   in  XOR       
        for i in range(0 , self.Step):  
            Morus_copy_XOR   = self.Create_variable("Morus_copyXOR"       , i , 3 , 1 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_XOR[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_copy_saved = self.Create_variable("Morus_copyXOR_saved" , i , 3 , 1 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write( Morus_copy_saved[j])
                fileobj_2.write('\n')  

    # The all  variables of 4th  round   in  XOR                 
        for i in range(0 , self.Step):  
            Morus_copy_XOR   = self.Create_variable("Morus_copyXOR"       , i , 4 , 2 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write(Morus_copy_XOR[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_copy_saved = self.Create_variable("Morus_copyXOR_saved" , i , 4 , 2 , range(0 , 128))
            for j in range(0 , 128):
                fileobj_2.write( Morus_copy_saved[j])
                fileobj_2.write('\n')  

    # The variables of AND in Rot_128_32
        for i in range(0 , self.Step):  
            Morus_AND_output  = self.Create_variable("AND" , i , 0  , 0 , range(0 , 128)) 
            for j in range(0 , 128):
                fileobj_2.write(Morus_AND_output[j])
                fileobj_2.write('\n') 

        for i in range(0 , self.Step):  
            Morus_AND_output  = self.Create_variable("AND" , i , 1  , 1 , range(0 , 128)) 
            for j in range(0 , 128):
                fileobj_2.write(Morus_AND_output[j])
                fileobj_2.write('\n')  

        for i in range(0 , self.Step):  
            Morus_AND_output  = self.Create_variable("AND" , i , 2  , 2 , range(0 , 128)) 
            for j in range(0 , 128):
                fileobj_2.write(Morus_AND_output[j])
                fileobj_2.write('\n') 

        for i in range(0 , self.Step):  
            Morus_AND_output  = self.Create_variable("AND" , i , 3  , 3 , range(0 , 128)) 
            for j in range(0 , 128):
                fileobj_2.write(Morus_AND_output[j])
                fileobj_2.write('\n')

        for i in range(0 ,self.Step):  
            Morus_AND_output  = self.Create_variable("AND" , i , 4  , 4 , range(0 , 128)) 
            for j in range(0 , 128):
                fileobj_2.write(Morus_AND_output[j])
                fileobj_2.write('\n')   

        for i in range(0 , 5):                                                                         # The initial state
            Morus_state = self.Create_variable('Morus_state' , 0 , 0 , i , range(0 , 128))
            for j in range(0 ,128):
                fileobj_2.write(Morus_state[j])
                fileobj_2.write('\n') 

        for i in range(0 , self.Step):
            Morus_next_round_128_1_0 = self.Create_variable('Morus_state' , i , 1 , 0 , range(0 , 128))
            for j in range(0 ,128):
                fileobj_2.write(Morus_next_round_128_1_0[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_next_round_128_1_0 = self.Create_variable('Morus_state' , i , 2 , 1 , range(0 , 128))
            for j in range(0 ,128):
                fileobj_2.write(Morus_next_round_128_1_0[j])
                fileobj_2.write('\n')

        for i in range(0 , self.Step):
            Morus_next_round_128_1_0 = self.Create_variable('Morus_state' , i , 3 , 2 , range(0 , 128))
            for j in range(0 ,128):
                fileobj_2.write(Morus_next_round_128_1_0[j])
                fileobj_2.write('\n')     

        for i in range(0 , self.Step):
            Morus_next_round_128_1_0 = self.Create_variable('Morus_state' , i , 4 , 3 , range(0 , 128))
            for j in range(0 ,128):
                fileobj_2.write(Morus_next_round_128_1_0[j])
                fileobj_2.write('\n')  

        for i in range(1 , self.Step + 1):
            Morus_next_round_128_1_0 = self.Create_variable('Morus_state' , i , 0 , 4 , range(0 , 128))
            for j in range(0 ,128):
                fileobj_2.write(Morus_next_round_128_1_0[j])
                fileobj_2.write('\n')

        fileobj_2.write('End')
        fileobj_2.close()
            
        
    def MakeModel(self):
        """
        Generate the MILP model of Present given the round number and activebits in file .
        """
        Morus_cipher_state0 = range(0 , 128)
        Morus_cipher_state1 = range(0 , 128)
        Morus_cipher_state2 = range(0 , 128)
        Morus_cipher_state3 = range(0 , 128)
        Morus_cipher_state4 = range(0 , 128)
        
        const0_32 = [0,0,0,1,0,1,0,2,0,3,0,5,0,8,0,13,1,5,2,2,3,7,5,9,9,0,14,9,7,9,6,2]
        const1_32 = [13,11,3,13,1,8,5,5,6,13,12,2,2,15,15,1,2,0,1,1,3,1,4,2,7,3,11,5,2,8,13,13]     
        
        
        
        const0_2 = []
        const1_2 = []
        
        for num in const0_32:
            const0_2.extend(self.shito2(num , 4)) 
            
        for num in const1_32:
            const1_2.extend(self.shito2(num , 4))      
            
        Non_cube      = [p for p in range(0 , 128) if p not in self.cube]  
        for i in self.cube:
            Morus_cipher_state0[i] = 'a'
            
        for i in range(0, len(Non_cube)):                                                        #    Error
            Morus_cipher_state0[Non_cube[i]] =  0

        for i in range(0 , 128):
            Morus_cipher_state1[i] = 'a'
            
        for i in range(0 , 128):
            Morus_cipher_state2[i] = 1
            
        for i in range(0 , 128):
            Morus_cipher_state3[i] =  const0_2[i]
            
        for i in range(0 , 128):
            Morus_cipher_state4[i] =  const1_2[i]
            
        self.Morus_num_step_Function_640_128(self.Step, Morus_cipher_state0, Morus_cipher_state1, Morus_cipher_state2, Morus_cipher_state3, Morus_cipher_state4)
        self.init()
        self.Binary() 
        

        
        
        
    def shito2(self, a, num):                     # 10 to 4bit 
        bit  = range(0 , num)
        for i in range(0 , num):
            bit[i] = ( a >> (num-1-i) ) & 1
        return bit[:]       
        
        
    def SolveModel(self):
        """
        Solve the MILP model to search the integral distinguisher of Present.
        """
       
        m2 = read(self.filename_model_2) 
        Morus_state1_128 = self.Create_variable('Morus_state' , 0 , 0 , 1 , range(0 , 128))
        
        
        eqn1 = range(0, 128)
            
        J = [ ]
        num = 0
        m2.optimize()
        while(m2.Status ==  2):
            J1 = []
            for i1 in range(0, 128):
                eqn1[i1] = m2.getVarByName((Morus_state1_128[i1]))
                if eqn1[i1].x >= 0.99:
                    J1.extend([i1])
           
            t_temp = self.t - 1
            m2.addConstr(eqn1[J1[0]] + eqn1[J1[1]] + eqn1[J1[2]] + eqn1[J1[3]] + eqn1[J1[4]] + eqn1[J1[5]] + eqn1[J1[6]] + eqn1[J1[7]] + eqn1[J1[8]] + eqn1[J1[9]]  <=   t_temp, "c1")             #
            J.append(J1)
            m2.update()
            m2.optimize()
        return J
            
        
        
        

    
    

        
        
        

        
        
        
            
        
        
        
        
        
