from Morus import Morus
import random
import time

if __name__ == "__main__":
    
    
    Step       =    6
    output_bit =    9
    Maxdegree  =    14
    cube        = [3, 4, 7, 15, 20, 24, 30, 31, 40, 43, 50, 60, 70, 79, 86, 89, 95, 96, 97, 102, 103, 106, 111, 116]
   
   
    start = time.time()
    t = 9
    MORUS1 = Morus(Step, cube , output_bit , t)              # t is the degree be tested
    MORUS1.MakeModel()
    C = MORUS1.SolveModel() 
    num = len(C)
    end = time.time()
    
    
    file2 = open("result2.txt" ,"a+")           
    file2.write("\nThe number of " + str(t) + "-degree monomials may involve in the superpoly:")
    file2.write(str(num))
    file2.write("\n")  
    file2.write("\nThe elements appeared in J_" + str(t) +  ":\n")
    file2.write(str(C))
    file2.write("\n")      
    file2.write("The time consumed by solver��")
    file2.write(str(end - start))
    file2.write("\n")
    file2.close()
