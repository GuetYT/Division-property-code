from Morus import Morus
import random
import time

if __name__ == "__main__":
    
    
    Step       =    6
    output_bit =    9
    Maxdegree  =    14
    cube        = [3, 4, 7, 15, 20, 24, 30, 31, 40, 43, 50, 60, 70, 79, 86, 89, 95, 96, 97, 102, 103, 106, 111, 116]
    key_bit_involved = [1, 5, 7, 8,26, 34, 36,45, 46, 47,48, 54, 58,64, 84, 94,105, 112,117, 125]
   
    start = time.time()
    t = 7
    MORUS1 = Morus(Step, cube , output_bit , t, key_bit_involved)              # t is the degree be tested
    MORUS1.MakeModel()
    C = MORUS1.SolveModel() 
    num = len(C)
    end = time.time()
    
    
    file2 = open("result2.txt" ,"a+")           
    file2.write("\nThe number of elements in S_" + str(t) + ":\n")
    file2.write(str(num))
    file2.write("\n")  
    file2.write("\nAll elements in S_" + str(t) + ":\n")
    file2.write(str(C))
    file2.write("\n")      
    file2.write("\nThe time consumed by solver��\n")
    file2.write(str(end - start))
    file2.write("\n")
    file2.close()

