This code can be used to get partial set of 12-degree monomials may involve in the superpoly. In this code, the cube is [3, 4, 7, 15, 20, 24, 30, 31, 40, 43, 50, 60, 70, 79, 86, 89, 95, 96, 97, 102, 103, 106, 111, 116], the key bits involveed in the superpoly is [1, 5, 7, 8,26, 34, 36,45, 46, 47,48, 54, 58,64, 84, 94,105, 112,117, 125], the upperbounding degree of superpoly is 14. 




In the function of "MORUS_main.py", the set "cube" is the cube index, the set of "key_bit_involveed" is the key bits may involved in the superpoly, if we want to get all 12-degree monomials may involve in the superpoly, the variable "t" should equal to 12. 




In the code of "Morus.py", we use the function of 'Creat_item_involve( )' to reduce the searching space of solver. Some lazy constraints are appended in the MILP model by using the function of "m2.addConstr(eqn1[J1[0]]+......+eqn1[J1[11]] <= 11)" in  "SolveModel( )", until the model is infeasible.

The set of highest degree monomials is written in the file of "result2.txt" .