import itertools
import time
if __name__ == "__main__":
    start = time.time()
    
    vector_involve_opt= []
    
    vector_larger =   [[5, 7, 8, 34, 45, 47, 48, 54, 58, 64, 105, 112, 117, 125],[5, 8, 26, 34, 47, 48, 54, 58, 64, 105, 112, 117, 125], [1, 5, 8, 34, 47, 48, 54, 58, 64, 105, 112, 117, 125], [5, 7, 34, 45, 46, 47, 48, 54, 58, 64, 105, 112, 125], [5, 8, 34, 47, 48, 54, 58, 64, 84, 105, 112, 117, 125], [5, 7, 8, 36, 45, 47, 48, 54, 58, 64, 105, 112, 125], [5, 7, 34, 45, 47, 48, 54, 58, 64, 94, 105, 112, 125], [5, 7, 34, 36, 45, 47, 48, 54, 58, 64, 105, 112, 125], [5, 7, 8, 45, 47, 48, 54, 58, 64, 94, 105, 112, 125], [5, 7, 8, 45, 46, 47, 48, 54, 58, 64, 105, 112, 125],[1, 5, 34, 47, 48, 54, 58, 64, 94, 105, 112, 125], [5, 26, 34, 46, 47, 48, 54, 58, 64, 105, 112, 125], [1, 5, 34, 46, 47, 48, 54, 58, 64, 105, 112, 125], [5, 8, 26, 46, 47, 48, 54, 58, 64, 105, 112, 125], [1, 5, 34, 36, 47, 48, 54, 58, 64, 105, 112, 125], [1, 5, 8, 46, 47, 48, 54, 58, 64, 105, 112, 125], [5, 34, 47, 48, 54, 58, 64, 84, 94, 105, 112, 125], [5, 34, 36, 47, 48, 54, 58, 64, 84, 105, 112, 125], [5, 26, 34, 47, 48, 54, 58, 64, 94, 105, 112, 125], [1, 5, 8, 47, 48, 54, 58, 64, 94, 105, 112, 125], [5, 34, 46, 47, 48, 54, 58, 64, 84, 105, 112, 125], [5, 26, 34, 36, 47, 48, 54, 58, 64, 105, 112, 125], [5, 8, 26, 36, 47, 48, 54, 58, 64, 105, 112, 125], [5, 8, 36, 47, 48, 54, 58, 64, 84, 105, 112, 125], [5, 8, 47, 48, 54, 58, 64, 84, 94, 105, 112, 125], [1, 5, 8, 36, 47, 48, 54, 58, 64, 105, 112, 125], [5, 8, 26, 47, 48, 54, 58, 64, 94, 105, 112, 125], [5, 8, 46, 47, 48, 54, 58, 64, 84, 105, 112, 125]]

    
    test_degree   = int(raw_input("Input the degree: "))
    file2 = open("result_in"+ "_"+str(test_degree) + ".txt" ,"a+")
    eqn = [ ]
    for vector in vector_larger:
        for i in itertools.combinations(vector, test_degree):
            eqn.append(i)
    eqn1 = set(eqn)
    
    eqn2 = []
    for i in eqn1:
        eqn2.append(list(i))

    
    eqn2.extend(vector_involve_opt)
    print(len(eqn2))     
    end = time.time()
    file2.write("The degree tested��")
    file2.write(str(test_degree))
    file2.write("\n")
    file2.write("The number of "+ str(test_degree )+"-degree monomials may involve in the superpoly��")
    file2.write(str(len(eqn2)))
    file2.write("\n")
    file2.write("The time consumed by solver:")
    file2.write(str(end - start))
    file2.write("\n")
    file2.write("The elements appeared in J_"+str(test_degree)+ ":\n" )
    file2.write(str(eqn2))
    file2.close()
    

    
      
    
    
 
   
